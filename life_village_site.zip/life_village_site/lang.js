
// lang.js - simple language toggle and single-nav behavior
(function(){
  const texts = {
    "tr": {},
    "en": {}
  };
  // Basic init: look for data-i18n attributes and switch
  function setLang(lang){
    document.querySelectorAll("[data-i18n]").forEach(el=>{
      const key = el.getAttribute("data-i18n");
      const txt = translations[lang] && translations[lang][key];
      if(txt!==undefined){
        if(el.tagName.toLowerCase()==='input' || el.tagName.toLowerCase()==='textarea'){
          el.placeholder = txt;
        } else {
          el.innerHTML = txt;
        }
      }
    });
    // Store choice
    localStorage.setItem("lv_lang", lang);
    // update active class
    document.querySelectorAll(".lang-toggle").forEach(btn=>{
      btn.classList.toggle("active", btn.dataset.lang===lang);
    });
  }

  const translations = {
    "tr":{
      "nav_home":"Ana Sayfa",
      "nav_about":"Hakkımızda",
      "nav_projects":"Projeler",
      "nav_contact":"İletişim",
      "hero_title":"Hayalinizdeki yaşamı, doğayla buluşturuyoruz.",
      "hero_sub":"Life Village Prefabrik Yapı — Antalya merkezli, modern prefabrik villalar ve yaşam alanları.",
      "cta_projects":"Projelerimize Bak",
      "cta_contact":"Teklif Al",
      "about_title":"Hakkımızda",
      "about_body":"Life Village, çevreyle uyumlu prefabrik yapılar tasarlar ve uygular. Misyonumuz konforlu, ekonomik ve estetik yaşam alanları sunmaktır.",
      "projects_title":"Örnek Projeler",
      "contact_title":"İletişim",
      "contact_phone":"Telefon: 0552 426 07 58",
      "contact_mail":"E-posta: info@lifevillage.com",
      "contact_address":"Antalya, Türkiye",
      "contact_form_name":"Adınız",
      "contact_form_mail":"E-posta",
      "contact_form_msg":"Mesajınız",
      "contact_form_send":"Gönder"
    },
    "en":{
      "nav_home":"Home",
      "nav_about":"About",
      "nav_projects":"Projects",
      "nav_contact":"Contact",
      "hero_title":"We bring your dream living together with nature.",
      "hero_sub":"Life Village Prefabrik Yapı — Antalya-based, modern prefabricated villas and living spaces.",
      "cta_projects":"View Projects",
      "cta_contact":"Get a Quote",
      "about_title":"About Us",
      "about_body":"Life Village designs and delivers eco-friendly prefabricated buildings. Our mission is to provide comfortable, cost-effective and beautiful living spaces.",
      "projects_title":"Sample Projects",
      "contact_title":"Contact",
      "contact_phone":"Phone: 0552 426 07 58",
      "contact_mail":"Email: info@lifevillage.com",
      "contact_address":"Antalya, Turkey",
      "contact_form_name":"Your name",
      "contact_form_mail":"Email",
      "contact_form_msg":"Message",
      "contact_form_send":"Send"
    }
  };

  window.LV = {
    setLang,
    translations
  };

  document.addEventListener("DOMContentLoaded",function(){
    // attach toggles
    document.querySelectorAll(".lang-toggle").forEach(btn=>{
      btn.addEventListener("click",()=>{ setLang(btn.dataset.lang); });
    });
    // initialize language
    const stored = localStorage.getItem("lv_lang") || "tr";
    setLang(stored);
    // simple nav highlighting
    const path = location.pathname.split("/").pop();
    document.querySelectorAll(".nav a").forEach(a=>{
      if(a.getAttribute("href")===path || (a.getAttribute("href")==='index.html' && path==='')){
        a.classList.add("active");
      }
    });
    // contact form - basic mailto fallback
    const form = document.getElementById("contact-form");
    if(form){
      form.addEventListener("submit", function(e){
        e.preventDefault();
        const name = form.querySelector("[name=name]").value;
        const mail = form.querySelector("[name=email]").value;
        const msg = form.querySelector("[name=message]").value;
        const subject = encodeURIComponent("Life Village - Web contact from " + name);
        const body = encodeURIComponent(msg + "\n\nFrom: " + name + "\nEmail: " + mail);
        location.href = "mailto:info@lifevillage.com?subject="+subject+"&body="+body;
      });
    }
  });

})();
