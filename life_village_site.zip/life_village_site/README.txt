
Life Village - Static site (Turkish + English)
Files:
- index.html
- about.html
- projects.html
- contact.html
- style.css
- lang.js
- assets/*.svg

How to use:
1) Unzip and open index.html in a browser for local preview.
2) To publish free: push repository to GitHub and enable GitHub Pages (use 'main' branch / root).
   OR drag & drop the folder to Netlify Drop (https://app.netlify.com/drop).
3) Contact form currently uses mailto: fallback. For a real backend, integrate Formspree, Netlify Forms or similar.

Notes:
- Language toggle stores selection in localStorage.
- Replace placeholder images in assets/ with project photos as needed.
- Update contact email in the footer and lang.js if desired.
